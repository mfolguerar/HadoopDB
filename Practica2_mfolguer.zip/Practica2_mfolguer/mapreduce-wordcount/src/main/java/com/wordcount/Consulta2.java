package com.wordcount;

import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
/**
 * Clase utilizada para realizar la consulta 2:Dada una estación y un año, obtener las medias de las medidas atmosféricas
recogidas por la estación.
 * @author marco
 *
 */
public class Consulta2 extends Configured implements Tool {
	/**
	 * Clase utilizada para delimitar y establecer los valores de la consulta
	 * @author Marcos Folguera Rivera
	 *
	 */
	public static class AirQualityMapper extends Mapper<Object, Text, Text, Text> {

		private static final String SEPARATOR = ",";

		/**
		 * Metodo utilizado para establecer las variables de la consultas leidas de input
		 */
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			final String[] values = value.toString().split(SEPARATOR);



			final String StateYear=context.getConfiguration().get("StateYear");

			String[] parts = StateYear.split("-");
			String State_aux = parts[0];
			String Year_aux = parts[1]; 

			final String Date = format(values[1]);
			//final String Time = format(values[2]);
			//final String Precicitation = format(values[3]);
			final String Atm_pressure = format(values[4]);
			//final String Max_pressure = format(values[5]);
			//	final String Min_pressure = format(values[6]);
			//final String Solar_radiation = format(values[7]);
			//final String Air_temp = format(values[8]);
			//	final String Dew_temp = format(values[9]);
			//final String Max_Temp = format(values[10]);
			//final String Min_Temp = format(values[11]);
			//final String Max_Dew_temp = format(values[12]);
			//final String Min_Dew_temp = format(values[13]);
			//final String Max_Humid_temp = format(values[14]);
			//	final String Min_Humid_temp = format(values[15]);
			//final String Relative_Humid = format(values[16]);
			//	final String Wind_direction = format(values[17]);			
			//final String Wind_gust = format(values[18]);
			//final String Wind_speed = format(values[19]);
			//final String Brazilian_geocopolitical = format(values[20]);
			final String State = format(values[21]);
			//final String Station_name = format(values[22]);
			//	final String Station_code = format(values[23]);
			//	final String Latitude = format(values[24]);
			//	final String Longitude = format(values[25]);
			//	final String Elevation = format(values[26]);
			try {

				String year=""+Date.charAt(1)+Date.charAt(2)+Date.charAt(3)+Date.charAt(4);

				if(State_aux.equals(State)&&Year_aux.equals(year)) {
					if (validacion(Atm_pressure)) {	
						context.write(new Text(StateYear),new Text(""+NumberUtils.toDouble(Atm_pressure)));

					}
				}
			}catch(Exception e) {

			}

		}
		/**
		 * Metodo utilizado para descartar los valores imposibles de las variables numericas
		 * @param value
		 * @return
		 */
		private boolean validacion(String value) {
			if(!NumberUtils.isNumber(value.toString())) {
				return false;
			}
			if(Double.parseDouble(value.toString())!=9999.0F &&Integer.parseInt(value.toString())!=-9999) {
				return false;
			}

			return true;
		}
		private String format(String value) {
			return value.trim();
		}
	}

	/**
	 * Clase utilizada para delimitar y seleccionar los valores de la consulta
	 * @author Marcos Folguera Rivera
	 *
	 */
	public static class AirQualityReducer extends Reducer<Text, Text, Text, Text> {


		private final DecimalFormat decimalFormat = new DecimalFormat("#.##");


		/**
		 * Metodo para obtener los valores pedidos en las consulta comparando entre todos ellos
		 * @param key la clave ,covalues->lista de los valores , context->archivo que los almacena 
		 */
		public void reduce(Text key, Iterable<Text> coValues, Context context) throws IOException, InterruptedException {	


			int cont=0;
			Double atm=0.00;
			for (Text coValue : coValues) {
				atm=atm+Double.parseDouble(coValue.toString());
				cont++;

			}
			if(cont>0) {
				atm=atm/cont;
			}else {
				atm=0.00;
			}

			String[] parts = key.toString().split("-");
			String State_aux = parts[0];
			String Year_aux = parts[1]; 

			context.write(new Text("En el Year:"+Year_aux+"y State:"+State_aux),new Text("Media= " +atm ));	
		}
	}
	/**
	 * Metodo que recopila parametros e inicialza los procesos para la lectura y escritura de la consulta
	 */
	@Override
	public int run(String[] args) throws Exception {
		Teclado t=new Teclado();
		if (args.length != 2) {
			System.err.println("AirQualityManager required params: {input file} {output dir}");
			System.exit(-1);
		}

		deleteOutputFileIfExists(args);
		Configuration configuration = new Configuration();
		final Job job = new Job(configuration);
		job.setJarByClass(Consulta2.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		configuration.set("StateYear",t.literalConString("Introduce el State-Year (N-2010):"));

		job.setMapperClass(AirQualityMapper.class);
		job.setReducerClass(AirQualityReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));


		job.waitForCompletion(true);

		return 0;
	}

	private void deleteOutputFileIfExists(String[] args) throws IOException {
		final Path output = new Path(args[1]);
		FileSystem.get(output.toUri(), getConf()).delete(output, true);
	}
	/**
	 * Metodo que lanza la consulta 2
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		Configuration configuration = new Configuration();
		ToolRunner.run(configuration, new Consulta2(), args);
	}
}
