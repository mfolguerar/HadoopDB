package com.wordcount;

import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
/**
 * Clase utilizada para realizar la consulta 1:Temperatura, humedad, presión atmosférica y radiación solar máxima y mínima
agrupada por región
 * @author marco
 *
 */
public class Consulta1 extends Configured implements Tool {
	/**
	 * Clase utilizada para delimitar y establecer los valores de la consulta
	 * @author Marcos Folguera Rivera
	 *
	 */
	public static class AirQualityMapper extends Mapper<Object, Text, Text, Text> {

		private static final String SEPARATOR = ",";

		/**
		 * Metodo utilizado para establecer las variables de la consultas leidas de input
		 */
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			final String[] values = value.toString().split(SEPARATOR);



			//final String year=context.getConfiguration().get("Year");




			//	final String Date = format(values[1]);
			//final String Time = format(values[2]);
			//final String Precicitation = format(values[3]);
			final String Atm_pressure = format(values[4]);
			//final String Max_pressure = format(values[5]);
			//	final String Min_pressure = format(values[6]);
			final String Solar_radiation = format(values[7]);
			//final String Air_temp = format(values[8]);
			//	final String Dew_temp = format(values[9]);
			final String Max_Temp = format(values[10]);
			final String Min_Temp = format(values[11]);
			//final String Max_Dew_temp = format(values[12]);
			//final String Min_Dew_temp = format(values[13]);
			//final String Max_Humid_temp = format(values[14]);
			//	final String Min_Humid_temp = format(values[15]);
			final String Relative_Humid = format(values[16]);
			//	final String Wind_direction = format(values[17]);			
			//final String Wind_gust = format(values[18]);
			//final String Wind_speed = format(values[19]);
			//final String Brazilian_geocopolitical = format(values[20]);
			final String State = format(values[21]);
			//final String Station_name = format(values[22]);
			//	final String Station_code = format(values[23]);
			//	final String Latitude = format(values[24]);
			//	final String Longitude = format(values[25]);
			//	final String Elevation = format(values[26]);


			if (validacion(Max_Temp)&&validacion(Min_Temp)&&validacion(Relative_Humid)&&validacion(Atm_pressure)&&validacion(Solar_radiation)) {	
				context.write(new Text(State),new Text(NumberUtils.toDouble(Max_Temp) + " " + NumberUtils.toDouble(Min_Temp)+ " " + NumberUtils.toDouble(Relative_Humid)+ " " + NumberUtils.toDouble(Atm_pressure)+ " " + NumberUtils.toDouble(Solar_radiation)));

			}
		}
		/**
		 * Metodo utilizado para descartar los valores imposibles de las variables numericas
		 * @param value
		 * @return
		 */
		private boolean validacion(String value) {
			if(!NumberUtils.isNumber(value.toString())) {
				return false;
			}
			if(Double.parseDouble(value.toString())!=9999.0F &&Integer.parseInt(value.toString())!=-9999) {
				return false;
			}
			
			return true;
		}
		private String format(String value) {
			return value.trim();
		}
	}

	/**
	 * Clase utilizada para delimitar y seleccionar los valores de la consulta
	 * @author Marcos Folguera Rivera
	 *
	 */
	public static class AirQualityReducer extends Reducer<Text, Text, Text, Text> {


		private final DecimalFormat decimalFormat = new DecimalFormat("#.##");


		/**
		 * Metodo para obtener los valores pedidos en las consulta comparando entre todos ellos
		 * @param key la clave ,covalues->lista de los valores , context->archivo que los almacena 
		 */
		public void reduce(Text key, Iterable<Text> coValues, Context context) throws IOException, InterruptedException {	

			Double Max_Temp=0.0;
			Double Min_Temp=0.0;
			Double Max_Relative_Humid=0.0;
			Double Min_Relative_Humid=0.0;
			Double Max_Atm_pressure=0.0;
			Double Min_Atm_pressure=0.0;
			Double Max_Solar_radiation=0.0;
			Double Min_Solar_radiation=0.0;
			String State =key.toString();
			String separator=" ";
			int contador=0;


			for (Text coValue : coValues) {

				String[] parts = coValue.toString().split(separator);
				if(contador==0) {
					Max_Temp = Double.parseDouble(parts[0]);
					Min_Temp=Double.parseDouble(parts[1]);
					Max_Relative_Humid =Double.parseDouble(parts[2]);
					Min_Relative_Humid =Double.parseDouble(parts[2]);
					Max_Atm_pressure =Double.parseDouble(parts[3]);
					Min_Atm_pressure =Double.parseDouble(parts[3]);
					Max_Solar_radiation=Double.parseDouble(parts[4]);
					Min_Solar_radiation=Double.parseDouble(parts[4]);
				}
				contador++;
				if ( Double.parseDouble(parts[0])>=Max_Temp) {
					Max_Temp=Double.parseDouble(parts[0]);
					State=key.toString();					
				}
				if ( Double.parseDouble(parts[1])<=Min_Temp) {
					Min_Temp=Double.parseDouble(parts[1]);
					State=key.toString();
				}
				if ( Double.parseDouble(parts[2])>=Max_Relative_Humid) {
					Max_Relative_Humid=Double.parseDouble(parts[2]);
					State=key.toString();
				}
				if ( Double.parseDouble(parts[2])<=Min_Relative_Humid) {
					Min_Relative_Humid=Double.parseDouble(parts[2]);
					State=key.toString();
				}
				if ( Double.parseDouble(parts[3])>=Max_Atm_pressure) {
					Max_Atm_pressure=Double.parseDouble(parts[3]);
					State=key.toString();
				}
				if ( Double.parseDouble(parts[3])<=Min_Atm_pressure) {
					Min_Atm_pressure=Double.parseDouble(parts[3]);
					State=key.toString();
				}
				if ( Double.parseDouble(parts[4])>=Max_Solar_radiation) {
					Max_Solar_radiation=Double.parseDouble(parts[4]);
					State=key.toString();
				}
				if ( Double.parseDouble(parts[4])<=Min_Solar_radiation) {
					Min_Solar_radiation=Double.parseDouble(parts[4]);
					State=key.toString();
				}
			}
			context.write(new Text("Temperatura->"), new Text(" Max:" +decimalFormat.format(Max_Temp) + "State :"+ State+"  .Min: " + decimalFormat.format(Min_Temp)+ "State :"+ State));
			context.write(new Text("Humedad relativa->"),new Text(" Max:" +decimalFormat.format(Max_Relative_Humid) + " State :"+ State+"  .Min: " + decimalFormat.format(Min_Relative_Humid)+ " State :"+ State));
			context.write(new Text("Presion  Atmosferica->"), new Text(" Max:" +decimalFormat.format(Max_Atm_pressure) + " State :"+ State+"  .Min: " + decimalFormat.format(Min_Atm_pressure)+ " State :"+ State));
			context.write(new Text("Radiacion solar->"),new Text(" Max:" +decimalFormat.format(Max_Solar_radiation) + " State :"+ State+"  .Min: " + decimalFormat.format(Min_Solar_radiation)+ " State :"+ State));	
		}
	}
	
	/**
	 * Metodo que recopila parametros e inicialza los procesos para la lectura y escritura de la consulta
	 */
	@Override
	public int run(String[] args) throws Exception {
		Teclado t=new Teclado();
		if (args.length != 2) {
			System.err.println("AirQualityManager required params: {input file} {output dir}");
			System.exit(-1);
		}

		deleteOutputFileIfExists(args);
		  Configuration configuration = new Configuration();
		final Job job = new Job(configuration);
		job.setJarByClass(Consulta1.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
	//	configuration.set("Year",t.literalConString("Year:"));

		job.setMapperClass(AirQualityMapper.class);
		job.setReducerClass(AirQualityReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));


		job.waitForCompletion(true);

		return 0;
	}

	private void deleteOutputFileIfExists(String[] args) throws IOException {
		final Path output = new Path(args[1]);
		FileSystem.get(output.toUri(), getConf()).delete(output, true);
	}
	/**
	 * Metodo que lanza la consulta 1
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
        Configuration configuration = new Configuration();
        ToolRunner.run(configuration, new Consulta1(), args);
    }
}
